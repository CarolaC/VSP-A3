Startkommandos:
===============

Zuerst: Namensdienst starten.
Achtung: Reihefolge muss eingehalten werden!!


Bank:
-----

java -cp .:bank.jar bank/Bank <ns-host> <ns-port>


Filiale:
--------

java -cp .:filiale.jar filiale/Filiale <ns-host> <ns-port>


Geldautomat:
------------

java -cp .:geldautomat.jar geldautomat/Geldautomat <ns-host> <ns-port>